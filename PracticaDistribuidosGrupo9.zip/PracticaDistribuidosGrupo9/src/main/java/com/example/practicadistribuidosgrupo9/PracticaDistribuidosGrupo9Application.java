package com.example.practicadistribuidosgrupo9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaDistribuidosGrupo9Application {

    public static void main(String[] args) {
        SpringApplication.run(PracticaDistribuidosGrupo9Application.class, args);
    }

}
